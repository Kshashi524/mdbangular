// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  production: false,
  url: {
    'aws': 'https://ig96qsti41.execute-api.us-east-2.amazonaws.com/dev',
    'gcloud': 'https://project-zapp.appspot.com',
    'local': 'http://localhost:9999'
  },
  firebase: {
    apiKey: "AIzaSyDl2h5Z5KAifmiL4bbgUelCK5fkMfSPbuU",
    authDomain: "project-zapp.firebaseapp.com",
    databaseURL: "https://project-zapp.firebaseio.com",
    projectId: "project-zapp",
    storageBucket: "project-zapp.appspot.com",
    messagingSenderId: "1054100004768"
  }
};
