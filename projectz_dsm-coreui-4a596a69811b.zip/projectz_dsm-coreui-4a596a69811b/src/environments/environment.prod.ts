export const environment = {
  production: true,
  url: {
    'aws': 'https://ig96qsti41.execute-api.us-east-2.amazonaws.com/dev',
    'gcloud': 'https://project-zapp.appspot.com',
    'local': 'http://localhost:9999'
  },
  firebase: {
    apiKey: "AIzaSyDl2h5Z5KAifmiL4bbgUelCK5fkMfSPbuU",
    authDomain: "project-zapp.firebaseapp.com",
    databaseURL: "https://project-zapp.firebaseio.com",
    projectId: "project-zapp",
    storageBucket: "project-zapp.appspot.com",
    messagingSenderId: "1054100004768"
  }
};
