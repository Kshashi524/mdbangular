import {Injectable} from "@angular/core";
import {Observable} from "rxjs/Observable";
import * as firebase from "firebase/app";
import {AngularFireAuth} from "angularfire2/auth";

@Injectable()
export class AuthService {

  userLoggedIn: boolean = false;
  user: Observable<firebase.User>

  constructor(private firebaseAuth: AngularFireAuth) {
    this.user = this.firebaseAuth.authState;
  }

  signup(email: string, password: string): Promise<any> {
    return this.firebaseAuth
              .auth
              .createUserAndRetrieveDataWithEmailAndPassword(email, password);
  }

  login(email: string, password: string): Promise<any>  {
    return this.firebaseAuth
              .auth
              .signInAndRetrieveDataWithEmailAndPassword(email, password);
  }

  signInWithTwitter(): Promise<any> {
    return this.firebaseAuth.auth.signInWithPopup(
      new firebase.auth.TwitterAuthProvider()
    )
  }

  signInWithFacebook(): Promise<any> {
    return this.firebaseAuth.auth.signInWithPopup(
      new firebase.auth.FacebookAuthProvider()
    )
  }

  signInWithGoogle(): Promise<any> {
    return this.firebaseAuth.auth.signInWithPopup(
      new firebase.auth.GoogleAuthProvider()
    )
  }

  logout(): Promise<any>  {
    return this.firebaseAuth
              .auth
              .signOut();
  }

}
