import {Component, OnInit} from '@angular/core';
import {FormControl, Validators} from "@angular/forms";
import {Router} from "@angular/router";
import {AuthService} from "../service/auth.service";
import {MatSnackBar} from "@angular/material";

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  email = new FormControl('', [Validators.required, Validators.email]);
  password = new FormControl('', [Validators.required]);
  confirmPassword = new FormControl('', [Validators.required]);
  hidePassword = true;
  hideConfirmPassword = true;

  constructor(private router: Router, private authService: AuthService, private snackBar: MatSnackBar) { }

  ngOnInit() {
  }

  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 5000,
    });
  }

  getEmailErrorMessage() {
    return this.email.hasError('required') ? 'You must enter a value' :
      this.email.hasError('email') ? 'Not a valid email' :
        '';
  }

  getPasswordErrorMessage() {
    return this.password.hasError('required') ? 'You must enter a value' : '';
  }

  getConfirmPasswordErrorMessage() {
    return this.password.hasError('required') ? 'You must enter a value' : this.password === this.confirmPassword ? 'Password didnt match' : '';
  }

  onSubmit() {
    this.authService.signup(this.email.value, this.password.value)
      .then(data => {
        console.log("Successfully registered with email and password", data);
        this.navigateToHome();
      })
      .catch(err => {
        console.error("Error during registration", err);
        this.openSnackBar("Registration Failed", err.message);
      });
  }

  navigateToHome() {
    this.router.navigateByUrl('/home').then(() => {}).catch(err => console.log("Error while navigating to Home"));
  }

  navigateToLogin() {
    this.router.navigateByUrl('/auth/login').then(() => {}).catch(err => console.log("Error while navigating to Login"));
  }

}
