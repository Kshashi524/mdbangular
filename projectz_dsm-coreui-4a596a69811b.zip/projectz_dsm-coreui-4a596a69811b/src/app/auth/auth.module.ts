import {NgModule} from '@angular/core';
import {LoginComponent} from './login/login.component';
import {RegisterComponent} from './register/register.component';
import {AppCommonModule} from "../common/common.module";
import {RouterModule} from "@angular/router";
import {AuthRoutes} from "./routing/auth.routing";
import {AuthService} from "./service/auth.service";

@NgModule({
  imports: [
    AppCommonModule, RouterModule.forChild(AuthRoutes)
  ],
  exports: [LoginComponent, RegisterComponent],
  declarations: [LoginComponent, RegisterComponent],
  providers: [AuthService]
})
export class AuthModule { }
