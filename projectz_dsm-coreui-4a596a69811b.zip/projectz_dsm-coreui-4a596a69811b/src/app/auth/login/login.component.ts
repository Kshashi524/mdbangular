import {Component, OnDestroy, OnInit} from '@angular/core';
import {FormControl, Validators} from "@angular/forms";
import {Router} from "@angular/router";
import {AuthService} from "../service/auth.service";
import {MatSnackBar} from "@angular/material";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit, OnDestroy {

  email = new FormControl('', [Validators.required, Validators.email]);
  password = new FormControl('', [Validators.required]);
  hide = true;

  constructor(private router: Router, private authService: AuthService, private snackBar: MatSnackBar) { }

  ngOnInit() {
  }

  ngOnDestroy() {
  }

  getEmailErrorMessage() {
    return this.email.hasError('required') ? 'You must enter a value' :
      this.email.hasError('email') ? 'Not a valid email' :
        '';
  }

  getPasswordErrorMessage() {
    return this.password.hasError('required') ? 'You must enter a value' : '';
  }

  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 5000,
      panelClass: 'blue-text'
    });
  }

  onSubmit() {
    this.authService.login(this.email.value, this.password.value)
      .then(data => {
        console.log("Successfully logged in with Email and Password", data);
        this.navigateToHome();
      })
      .catch(err => {
        console.error("Failed while login with Email and Password", err);
        this.openSnackBar("Login Failed", err.message);
      });
  }

  navigateToHome() {
    this.router.navigateByUrl('/home').then(() => {}).catch(err => console.log("Error while navigating to Home", err));
  }

  navigateToSignup() {
    this.router.navigateByUrl('/auth/register').then(() => {}).catch(err => console.log("Error while navigating to Register", err));
  }

  signInWithFacebook() {
    this.authService.signInWithFacebook()
      .then(data => {
        console.log("Successfully logged in with FB", data);
        this.navigateToHome();
      })
      .catch(err => {
        console.error("Failed while login with FB", err);
        this.openSnackBar("FB Login Failed", err.message);
      });
  }

  signInWithTwitter() {
    this.authService.signInWithTwitter()
      .then(data => {
        console.log("Successfully logged in with TW", data);
        this.navigateToHome();
      })
      .catch(err => {
        console.error("Failed while login with TW", err);
        this.openSnackBar("TW Login Failed", err.message);
      });
  }

  signInWithGoogle() {
    this.authService.signInWithGoogle()
      .then(data => {
        console.log("Successfully logged in with GP", data);
        this.navigateToHome();
      })
      .catch(err => {
        console.error("Failed while login with GP", err);
        this.openSnackBar("Google Login Failed", err.message);
      });
  }
}
