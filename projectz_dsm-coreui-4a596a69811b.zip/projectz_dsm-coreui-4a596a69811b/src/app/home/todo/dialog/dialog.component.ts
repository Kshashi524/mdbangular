import {Component, Inject, OnDestroy, OnInit} from '@angular/core';
import {FormControl, Validators} from "@angular/forms";
import {TodoService} from "../service/todo.service";
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material";

@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.scss']
})
export class DialogComponent implements OnInit, OnDestroy {

  isNewObject = false;
  viewInitialized = false;
  saveButtonLabel = 'Save';
  titleFormControl: FormControl = new FormControl('', [Validators.required]);
  descriptionFormControl: FormControl = new FormControl('', [Validators.required]);

  constructor(public todoDialog: MatDialogRef<DialogComponent>,
              private todoService: TodoService,
              @Inject(MAT_DIALOG_DATA) public data?: any) {
    this.isNewObject = (!data.title);
    this.saveButtonLabel = (data.title ? 'Update' : 'Save');
  }

  ngOnInit() {
    this.viewInitialized = true;
  }

  ngOnDestroy() {
    this.viewInitialized = false;
  }

  getErrorMessage(field: string): string {
    if (field === 'title') {
      return 'Event cannot be empty';
    }
    if (field === 'description') {
      return 'Description cannot be empty';
    }
    if (field === 'date') {
      return 'Date cannot be empty';
    }
  }

  saveTodo() {
    if(this.isNewObject) this.addTodo();
    else this.updateTodo();
  }

  addTodo() {
    this.todoService.addTodo(this.data)
      .subscribe(
        data => this.todoDialog.close(data),
        err => console.error("Error while saving TODO", err)
      );
  }

  updateTodo() {
    this.todoService.updateTodo(this.data)
      .subscribe(
        data => this.todoDialog.close(data),
        err => console.error("Error while updating TODO", err)
      );
  }
}
