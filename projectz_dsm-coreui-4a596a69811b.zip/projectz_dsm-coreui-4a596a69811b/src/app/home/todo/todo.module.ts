import {NgModule} from '@angular/core';
import {TodoComponent} from './todo.component';
import {AppCommonModule} from "../../common/common.module";
import {DialogComponent} from './dialog/dialog.component';
import {TodoService} from "./service/todo.service";
import {TodoFirebaseService} from "./service/todo.firebase.service";
import {TodoAwsService} from "./service/todo.aws.service";

@NgModule({
  imports: [AppCommonModule],
  declarations: [TodoComponent, DialogComponent],
  providers: [TodoService, TodoFirebaseService, TodoAwsService],
  entryComponents: [DialogComponent]
})
export class TodoModule { }
