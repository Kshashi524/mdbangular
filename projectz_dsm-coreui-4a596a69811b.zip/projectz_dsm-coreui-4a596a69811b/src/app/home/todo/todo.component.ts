import {Component, OnDestroy, OnInit} from '@angular/core';
import {MatDialog} from "@angular/material";
import {DialogComponent} from "./dialog/dialog.component";
import {TodoService} from "./service/todo.service";
import {isNullOrUndefined} from "util";
import {Todo} from "./domain/todo";
import {Observable} from "rxjs/Observable";
import {SharedService} from "../../common/service/shared.service";
import {ObservableMedia} from "@angular/flex-layout";
import {LoadingBarService} from "@ngx-loading-bar/core";
import * as _ from 'lodash';
import {AppService} from "../../service/app.service";
import {Subscription} from "rxjs/Subscription";

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.scss']
})
export class TodoComponent implements OnInit, OnDestroy {
  viewInitialized= false;
  selectedItem: any;
  todos = [];
  appServiceSubscription: Subscription;

  constructor(private todoDialog: MatDialog,
              private media: ObservableMedia,
              public loader: LoadingBarService,
              private sharedService: SharedService,
              public todoService: TodoService,
              private appService: AppService) {
  }

  ngOnInit() {
    this.viewInitialized = true;
    this.appServiceSubscription = this.appService.targetState.subscribe(() => this.loadTodos());
    this.loadTodos();
  }

  ngOnDestroy() {
    this.viewInitialized = false;
    this.appServiceSubscription.unsubscribe();
  }

  loadTodos() {
    this.todos = [];
    this.loader.start();
    this.todoService.getTodos().subscribe(data => {
      this.loader.complete();
      this.todos = data;
    }, err => {this.loader.complete();});
  }

  showTodoDialog(element?: any) {
    this.selectedItem = element ? {...element} : {};
    const width = this.media.isActive('lt-lg') ? '80%' : '40%';
    const todoDialog = this.todoDialog.open(DialogComponent, {
      width: width,
      data: this.selectedItem
    });
    todoDialog.afterClosed()
      .subscribe(
        data => {
          if(!isNullOrUndefined(data) && this.sharedService.target !== 'Firebase') {
            if(this.selectedItem && this.selectedItem.id) {
              const index = _.findIndex(this.todos, ['id', this.selectedItem.id]);
              this.todos[index] = data;
            } else {
              this.todos.push(data)
            }
          }
        },
        err => console.error("Error occurred while closing TODO dialog", err)
      );
  }

  taskCompleted(element: any) {
    this.todoService.updateTodo(element)
      .subscribe(
        data => console.log("Task completed", data),
        err => console.error("Error while completing the task", err)
      );
  }

  deleteCompletedRecords() {
    const recordsToBeDeleted = this.todos.filter(todo => todo.completed);
    if(recordsToBeDeleted.length==0) return;
    let loop = (todo: Todo) => {
      this.deleteRecord(todo).subscribe(result => {
        console.log("Record deleted", result);
        const index = this.todos.indexOf(todo);
        if(index >= 0) {
          this.todos.splice(index, 1);
        }
        if(recordsToBeDeleted.length>0) {
          loop(recordsToBeDeleted.shift());
        }
      }, err => console.error("Error while deleting record", err))
    };
    loop(recordsToBeDeleted.shift());
  }

  deleteRecord(todo: Todo): Observable<any> {
    return this.todoService.deleteTodo(todo);
  }
}
