import {Injectable} from "@angular/core";
import {AngularFirestore, AngularFirestoreCollection} from "angularfire2/firestore";
import {Todo} from "../domain/todo";
import {Observable} from "rxjs/Observable";

@Injectable()
export class TodoFirebaseService {

  todoCollectionRef: AngularFirestoreCollection<Todo>;

  constructor(private angularFirestore: AngularFirestore) {
    this.todoCollectionRef = this.angularFirestore.collection('todos');
  }


  getTodo(): Observable<any> {
    return this.todoCollectionRef.snapshotChanges().map(actions => {
      return actions.map(action => {
        const data = action.payload.doc.data() as Todo;
        const id = action.payload.doc.id;
        return { id, ...data };
      });
    });
  }

  addTodo(todo: Todo): Promise<any> {
    return this.todoCollectionRef.add(<Todo>{...todo});
  }

  updateTodo(todo: Todo): Promise<any> {
    return this.todoCollectionRef.doc(todo.id).update({...todo});
  }

  deleteTodo(todo: Todo): Promise<any> {
    return this.todoCollectionRef.doc(todo.id).delete();
  }
}
