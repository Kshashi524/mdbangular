import {Injectable} from '@angular/core';
import {Todo} from "../domain/todo";
import {Observable} from "rxjs/Observable";
import {TodoFirebaseService} from "./todo.firebase.service";
import {TodoAwsService} from "./todo.aws.service";
import {SharedService} from "../../../common/service/shared.service";
import {AWS, FIREBASE, GCLOUD, LOCAL} from "../../../common/constants/cloud";

@Injectable()
export class TodoService {

  constructor(private todoFirebaseService: TodoFirebaseService, private todoAwsService: TodoAwsService, private sharedService: SharedService) {
  }

  getTodos<T>(): Observable<any> {
    if(this.sharedService.target === FIREBASE) {
      return this.todoFirebaseService.getTodo();
    } else if(this.sharedService.target === AWS || this.sharedService.target === GCLOUD || this.sharedService.target === LOCAL) {
      return this.todoAwsService.getTodos();
    }
    return null;
  }

  addTodo(todo: Todo): Observable<any> {
    if(this.sharedService.target === FIREBASE) {
      return Observable.fromPromise(this.todoFirebaseService.addTodo(todo));
    } else if(this.sharedService.target === AWS || this.sharedService.target === GCLOUD || this.sharedService.target === LOCAL) {
      return this.todoAwsService.addTodo(todo);
    }
    return null;
  }

  updateTodo(todo: Todo): Observable<any> {
    if(this.sharedService.target === FIREBASE) {
      return Observable.fromPromise(this.todoFirebaseService.updateTodo(todo));
    } else if(this.sharedService.target === AWS || this.sharedService.target === GCLOUD || this.sharedService.target === LOCAL) {
      return this.todoAwsService.updateTodo(todo);
    }
    return null;
  }

  deleteTodo(todo: Todo): Observable<any> {
    if(this.sharedService.target === FIREBASE) {
      return Observable.fromPromise(this.todoFirebaseService.deleteTodo(todo));
    } else if(this.sharedService.target === AWS || this.sharedService.target === GCLOUD || this.sharedService.target === LOCAL) {
      return this.todoAwsService.deleteTodo(todo);
    }
    return null;
  }

}
