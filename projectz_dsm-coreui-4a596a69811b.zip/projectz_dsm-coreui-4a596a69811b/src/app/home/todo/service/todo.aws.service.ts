import {Injectable} from '@angular/core';
import {Todo} from "../domain/todo";
import {Observable} from "rxjs/Observable";
import {CoreHttpService} from "../../../common/http/core.http.service";

@Injectable()
export class TodoAwsService {
  url = '/core/todos';

  constructor(private http: CoreHttpService) {
  }

  getTodos<T>(): Observable<any> {
    const url = this.url;
    return this.http.get(url).map(data => data['_embedded'].todos);
  }

  addTodo(todo: Todo): Observable<any> {
    const url = this.url;
    return this.http.post(url, todo);
  }

  updateTodo(todo: Todo): Observable<any> {
    const url = todo['_links'].self.href;
    return this.http.patch(url, todo);
  }

  deleteTodo(todo: Todo): Observable<any> {
    const url = todo['_links'].self.href;
    return this.http.delete(url);
  }

}
