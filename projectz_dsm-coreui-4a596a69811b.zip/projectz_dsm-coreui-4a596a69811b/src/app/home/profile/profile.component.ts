import {Component, OnDestroy, OnInit} from '@angular/core';
import {FormControl, Validators} from "@angular/forms";
import {SharedService} from "../../common/service/shared.service";

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit, OnDestroy {

  viewInitialized = false;
  username = new FormControl('', [Validators.required]);

  constructor(private sharedService: SharedService) { }

  ngOnInit() {
    this.viewInitialized = true;
    this.loadProfile();
  }

  ngOnDestroy() {
  }

  loadProfile() {
  }

  getErrorMessage(value: string): string {
    if(value === 'username') return this.username.hasError('required') ? 'You must enter a value' : '';
    return 'Error';
  }

  onSubmit() {
  }
}
