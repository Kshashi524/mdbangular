import {NgModule} from '@angular/core';
import {ProfileComponent} from './profile.component';
import {AppCommonModule} from "../../common/common.module";

@NgModule({
  imports: [AppCommonModule],
  exports: [ProfileComponent],
  declarations: [ProfileComponent]
})
export class ProfileModule { }
