import {Routes} from "@angular/router";
import {HomeComponent} from "../home.component";
import {AuthGuardService} from "../../auth/service/auth.guard.service";
import {DashboardComponent} from "../dashboard/dashboard.component";
import {TodoComponent} from "../todo/todo.component";
import {ProfileComponent} from "../profile/profile.component";

export const HomeRoutes: Routes = [
  {
    path: '', component: HomeComponent,
    children: [
      {path: 'dashboard', canActivate: [AuthGuardService], component: DashboardComponent},
      {path: 'todo', canActivate: [AuthGuardService], component: TodoComponent},
      {path: 'profile', canActivate: [AuthGuardService], component: ProfileComponent},
      {path: '', redirectTo: 'dashboard', pathMatch: 'full'}
    ]
  }
];
