import {NgModule} from '@angular/core';
import {HomeComponent} from './home.component';
import {AppCommonModule} from "../common/common.module";
import {RouterModule} from "@angular/router";
import {HomeRoutes} from "./routing/home.routing";
import {DashboardModule} from "./dashboard/dashboard.module";
import {TodoModule} from "./todo/todo.module";
import {ProfileModule} from "./profile/profile.module";

@NgModule({
  imports: [
    AppCommonModule, RouterModule.forChild(HomeRoutes),
    DashboardModule, TodoModule, ProfileModule
  ],
  declarations: [HomeComponent]
})
export class HomeModule { }
