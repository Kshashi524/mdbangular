import {NgModule} from '@angular/core';
import {DashboardComponent} from './dashboard.component';
import {AppCommonModule} from "../../common/common.module";

@NgModule({
  imports: [AppCommonModule],
  exports: [DashboardComponent],
  declarations: [DashboardComponent]
})
export class DashboardModule { }
