import {ChangeDetectorRef, Component, OnDestroy, OnInit} from '@angular/core';
import {MediaMatcher} from "@angular/cdk/layout";
import {Router} from "@angular/router";
import {AuthService} from "../auth/service/auth.service";
import {clouds, LOCAL} from "../common/constants/cloud";
import {SharedService} from "../common/service/shared.service";
import {AppService} from "../service/app.service";

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit, OnDestroy {

  mobileQuery: MediaQueryList;

  cloudList = [];
  cloudProvider = 'Choose a cloud provider';
  targetSubscription: any;

  private _mobileQueryListener: () => void;

  constructor(changeDetectorRef: ChangeDetectorRef,
              media: MediaMatcher,
              private router: Router,
              private sharedService: SharedService,
              private appService: AppService,
              private authService: AuthService) {
    this.mobileQuery = media.matchMedia('(max-width: 959px)');
    this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addListener(this._mobileQueryListener);
    this.targetSubscription = this.appService.targetState.subscribe(() => this.appService.validateSession());
  }

  ngOnInit() {
    this.cloudList = clouds;
    this.updateCloudProvider(LOCAL);
  }

  ngOnDestroy(): void {
    this.mobileQuery.removeListener(this._mobileQueryListener);
    this.targetSubscription.unsubscribe();
  }

  isCurrentRoute(value: string) {
    return this.router.url === value;
  }

  navigateToHome() {
    this.router.navigateByUrl('/').then().catch(err => console.error("Error during navigating to home", err));
  }

  navigateToProfile() {
    this.router.navigateByUrl('/home/profile').then().catch(err => console.error("Error during navigating to home", err));
  }

  logoutClickHandler() {
    this.authService.logout().then().catch(err => console.error("Error during logout", err));
  }

  updateCloudProvider(cloud: string) {
    this.sharedService.target = this.cloudProvider = cloud;
    this.appService.targetSubjectChangeHandler();
  }
}
