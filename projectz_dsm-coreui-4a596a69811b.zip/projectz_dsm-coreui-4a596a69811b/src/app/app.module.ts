import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';


import {AppComponent} from './app.component';
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import {PageNotFoundComponent} from './page-not-found/page-not-found.component';
import {RouterModule} from "@angular/router";
import {AppRoutes} from "./routing/app.routing";
import {ToastrModule} from "ngx-toastr";
import {LoadingBarHttpClientModule} from "@ngx-loading-bar/http-client";
import {LoadingBarHttpModule} from "@ngx-loading-bar/http";
import {LoadingBarModule} from "@ngx-loading-bar/core";
import {LoadingBarRouterModule} from "@ngx-loading-bar/router";
import {FlexLayoutModule} from "@angular/flex-layout";
import {AuthGuardService} from "./auth/service/auth.guard.service";
import {AuthService} from "./auth/service/auth.service";
import {AngularFireAuthModule} from "angularfire2/auth";
import {environment} from "../environments/environment";
import {AngularFireModule} from "angularfire2";
import {AngularFirestoreModule} from "angularfire2/firestore";
import {ANIMATION_TYPES, LoadingModule} from "ngx-loading";
import {AppCommonModule} from "./common/common.module";
import {SharedService} from "./common/service/shared.service";
import {AppService} from "./service/app.service";

@NgModule({
  declarations: [
    AppComponent,
    PageNotFoundComponent
  ],
  imports: [
    BrowserModule, BrowserAnimationsModule, RouterModule.forRoot(AppRoutes), ToastrModule.forRoot(),
    FlexLayoutModule, AppCommonModule,
    LoadingModule.forRoot({
      animationType: ANIMATION_TYPES.threeBounce,
      backdropBackgroundColour: 'rgba(0,0,0,0.1)',
      backdropBorderRadius: '4px',
      primaryColour: '#ffb300',
      secondaryColour: '#fff59d',
      tertiaryColour: '#9ccc65'
    }),
    AngularFireModule.initializeApp(environment.firebase),
    AngularFireAuthModule,
    AngularFirestoreModule.enablePersistence(),
    LoadingBarHttpClientModule, LoadingBarHttpModule, LoadingBarRouterModule, LoadingBarModule.forRoot()
  ],
  providers: [AuthService, AuthGuardService, SharedService, AppService],
  bootstrap: [AppComponent]
})
export class AppModule { }
