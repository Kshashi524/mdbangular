export const FIREBASE = "Firebase";
export const AWS = "Aws";
export const GCLOUD = "Gcloud";
export const LOCAL = "Local";
export const clouds = [FIREBASE, AWS, GCLOUD, LOCAL];
