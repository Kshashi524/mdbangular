import {NgModule} from '@angular/core';
import {CommonModule} from "@angular/common";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {FlexLayoutModule} from "@angular/flex-layout";
import {MaterialModule} from "./material/material.module";
import {HTTP_INTERCEPTORS, HttpClient, HttpClientModule, HttpHandler} from "@angular/common/http";
import {CoreHttpService} from "./http/core.http.service";
import {coreHttpFactory} from "./http/core.http.factory";
import {SharedService} from "./service/shared.service";
import {CoreHttpInterceptor} from "./http/core.http.interceptor";

const COMMON_MODULES = [CommonModule, ReactiveFormsModule, FormsModule, FlexLayoutModule, MaterialModule, HttpClientModule];

@NgModule({
  imports: [COMMON_MODULES],
  exports: [COMMON_MODULES],
  declarations: [],
  providers: [
    CoreHttpService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: CoreHttpInterceptor,
      multi: true
    },
    {
      provide: HttpClient,
      useFactory: coreHttpFactory,
      deps: [HttpHandler, SharedService]
    }
  ]
})
export class AppCommonModule { }
