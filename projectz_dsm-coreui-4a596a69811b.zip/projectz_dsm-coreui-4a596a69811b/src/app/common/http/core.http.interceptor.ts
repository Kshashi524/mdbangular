import {Injectable} from "@angular/core";
import {
  HttpErrorResponse,
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
  HttpResponse
} from "@angular/common/http";
import {Observable} from "rxjs/Observable";
import {SharedService} from "../service/shared.service";
import {isNullOrUndefined} from "util";

@Injectable()
export class CoreHttpInterceptor implements HttpInterceptor {

  constructor(public sharedService: SharedService) {}

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    let request = req.clone();

    if(isNullOrUndefined(req.headers.get('Authorization'))) {
      const username = (!isNullOrUndefined(this.sharedService.userMetadata['email'])) ? this.sharedService.userMetadata['email'] : this.sharedService.userMetadata['displayName'];
      const password = this.sharedService.userMetadata['uid'];
      request = req.clone({headers: req.headers.set('Authorization', 'Basic '+btoa(username+":"+password))});
    }

    return next.handle(request).do((event: HttpEvent<any>) => {
      if(event instanceof HttpResponse) {
        console.log(event);
      }
    }, err => {
      if(err instanceof HttpErrorResponse) {
        console.error(err);
      }
    });
  }
}
