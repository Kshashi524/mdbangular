import {Injectable} from '@angular/core';

import {environment} from '../../../environments/environment';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/finally';
import 'rxjs/add/observable/throw';
import {HttpClient, HttpHandler, HttpHeaders} from "@angular/common/http";
import {SharedService} from "../service/shared.service";
import {AWS, GCLOUD, LOCAL} from "../constants/cloud";

@Injectable()
export class CoreHttpService extends HttpClient {

  constructor(httpHandler: HttpHandler, public sharedService: SharedService) {
    super(httpHandler);
  }

  get(url: string, options?: any): Observable<any> {
    url = this.updateUrl(url);
    return super.get(url, this.getRequestOptionArgs(options))
      .catch(this.onCatch)
      .finally(() => {
        this.onEnd();
      });
  }

  post(url: string, body: any, options?: any): Observable<any> {
    url = this.updateUrl(url);
    return super.post(url, body, this.getRequestOptionArgs(options))
      .catch(this.onCatch)
      .finally(() => {
        this.onEnd();
      });

  }

  put(url: string, body: any, options?: any): Observable<any> {
    url = this.updateUrl(url);
    return super.put(url, body, this.getRequestOptionArgs(options))
      .catch(this.onCatch)
      .finally(() => {
        this.onEnd();
      });

  }

  delete(url: string, options?: any): Observable<any> {
    url = this.updateUrl(url);
    return super.delete(url, this.getRequestOptionArgs(options))
      .catch(this.onCatch)
      .finally(() => {
        this.onEnd();
      });

  }

  patch(url: string, body: any, options?: any): Observable<any> {
    url = this.updateUrl(url);
    return super.patch(url, body, this.getRequestOptionArgs(options))
      .catch(this.onCatch)
      .finally(() => {
        this.onEnd();
      });
  }

  private getRequestOptionArgs(options?: any): any {
    if (options == null) {
      options = {};
    }
    if (options.headers == null) {
      options.headers = new HttpHeaders({'Content-Type': 'application/patch+json'});
    }

    return options;
  }

  private updateUrl(req: string) {
    if(req.indexOf('http') >= 0) return req;
    if(this.sharedService.target === AWS) return environment.url.aws + req;
    else if(this.sharedService.target === GCLOUD) return environment.url.gcloud + req;
    else if(this.sharedService.target === LOCAL) return environment.url.local + req;
  }

  private onCatch(error: any, caught: Observable<any>): Observable<any> {
    return Observable.throw(error);
  }

  private onEnd(): void {
  }

}
