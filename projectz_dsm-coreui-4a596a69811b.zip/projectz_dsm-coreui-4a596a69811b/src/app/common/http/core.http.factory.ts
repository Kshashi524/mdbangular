import {CoreHttpService} from './core.http.service';
import {HttpClient, HttpHandler} from "@angular/common/http";
import {SharedService} from "../service/shared.service";


export function coreHttpFactory(handler: HttpHandler, sharedService: SharedService): HttpClient {
  return new CoreHttpService(handler, sharedService);
}
