import {NgModule} from '@angular/core';
import {
  MatAutocompleteModule, MatButtonModule, MatButtonToggleModule, MatCardModule, MatCheckboxModule,
  MatDatepickerModule, MatDialogModule, MatExpansionModule, MatFormFieldModule, MatIconModule, MatIconRegistry,
  MatInputModule, MatListModule, MatMenuModule, MatNativeDateModule, MatPaginatorModule, MatProgressBarModule,
  MatProgressSpinnerModule, MatRadioModule, MatSelectModule, MatSidenavModule, MatSnackBarModule, MatSortModule,
  MatStepperModule, MatTableModule, MatTabsModule, MatToolbarModule
} from '@angular/material';

const MAT_MODULES = [MatFormFieldModule, MatButtonModule, MatInputModule, MatCardModule, MatTableModule,
  MatIconModule, MatCheckboxModule, MatToolbarModule, MatMenuModule, MatSidenavModule, MatDialogModule,
  MatDatepickerModule, MatNativeDateModule, MatSnackBarModule, MatSelectModule, MatPaginatorModule,
  MatSidenavModule, MatListModule, MatTabsModule, MatSortModule, MatExpansionModule, MatButtonToggleModule,
  MatProgressSpinnerModule, MatProgressBarModule, MatProgressBarModule, MatRadioModule, MatStepperModule, MatAutocompleteModule];

@NgModule({
  imports: [MAT_MODULES],
  exports: [MAT_MODULES],
  providers: [MatIconRegistry]
})

export class MaterialModule { }
