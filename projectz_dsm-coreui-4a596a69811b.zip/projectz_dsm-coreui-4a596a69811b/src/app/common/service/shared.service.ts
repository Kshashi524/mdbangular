import {Injectable} from "@angular/core";

@Injectable()
export class SharedService {

  target: any;
  loading = false;
  userMetadata: any = {};

}
