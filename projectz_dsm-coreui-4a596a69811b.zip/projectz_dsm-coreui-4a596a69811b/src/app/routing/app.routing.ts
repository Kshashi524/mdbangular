import {Routes} from "@angular/router";
import {PageNotFoundComponent} from "../page-not-found/page-not-found.component";
import {AuthGuardService} from "../auth/service/auth.guard.service";

export const AppRoutes: Routes = [
  {path: 'auth', canActivate: [AuthGuardService], loadChildren: 'app/auth/auth.module#AuthModule'},
  {path: 'home', canActivate: [AuthGuardService], loadChildren: 'app/home/home.module#HomeModule'},
  {path: '', redirectTo: 'home', pathMatch: 'full'},
  {path: '**', component: PageNotFoundComponent}
];
