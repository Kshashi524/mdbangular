import {Component, OnDestroy, OnInit} from '@angular/core';
import {AuthService} from "./auth/service/auth.service";
import {Subscription} from "rxjs/Subscription";
import {isNullOrUndefined} from "util";
import {Router} from "@angular/router";
import {SharedService} from "./common/service/shared.service";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, OnDestroy{
  authSubscription: Subscription;

  constructor(public authService: AuthService, public router: Router, public sharedService: SharedService) {
    this.sharedService.loading = true;
    this.authSubscription = this.authService.user.subscribe(data => this.authStateChanged(data));
  }

  ngOnInit() {
    this.sharedService.loading = false;
  }

  ngOnDestroy() {
  }

  authStateChanged(data: any) {
    if(!isNullOrUndefined(data)) {
      this.authService.userLoggedIn = true;
      this.loadUserDetails(data);
      this.navigateToHome();
    } else {
      this.authService.userLoggedIn = false;
      this.navigateToLogin();
    }
  }

  loadUserDetails(data: any) {
    this.sharedService.userMetadata = data;
  }

  navigateToHome() {
    this.router.navigateByUrl('/home').then(() => {}).catch(err => console.log("Error while navigating to Home"));
  }

  navigateToLogin() {
    this.router.navigateByUrl('/auth').then(() => {}).catch(err => console.log("Error while navigating to Home"));
  }

}
