import {Injectable} from "@angular/core";
import {SharedService} from "../common/service/shared.service";
import {CoreHttpService} from "../common/http/core.http.service";
import {Subject} from "rxjs/Subject";
import {isNullOrUndefined} from "util";

@Injectable()
export class AppService {
  url = '/core/ping';

  targetSubject = new Subject();
  targetState = this.targetSubject.asObservable();

  constructor(private http: CoreHttpService, private sharedService: SharedService) {}

  validateSession(): void {
    const url = this.url;
    this.http.get(url)
      .subscribe(
        data => console.log("Success : User is available", data),
          err => {
            if(err.status === 401) {
              this.createUser();
            }
            console.error("Failed : User is not available", err);
          });
  }

  createUser(): void {
    const url = '/core/users';
    const username = (!isNullOrUndefined(this.sharedService.userMetadata['email'])) ? this.sharedService.userMetadata['email'] : this.sharedService.userMetadata['displayName'];
    const user = {'username': username, 'password': this.sharedService.userMetadata['uid']};
    this.http.post(url, user, {headers: {"Authorization": 'Basic YWRtaW46cGFzc3dvcmQ='}})
      .subscribe(
        data => console.log("Success : created use", data),
        err => console.error("Failed : issue when creating user", err)
      );
  }

  targetSubjectChangeHandler() {
    this.targetSubject.next();
  }
}
